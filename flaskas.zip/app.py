from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://admin:qwertyuiop@flaskdb.cdfu3l8rlui4.us-east-1.rds.amazonaws.com/awsflask'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = "somethingunique"

db = SQLAlchemy(app)


class Data(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    task = db.Column(db.String(100), nullable=False)
    des = db.Column(db.String(100), nullable=False)
    dat = db.Column(db.Date)

    def __init__(self, task, des, dat):
        self.task = task
        self.des = des
        self.dat = dat

@app.route('/')
def index():
    datas = Data.query.all()
    return render_template('index.html', datas=datas)
    # return render_template('index.html')

@app.route('/add/', methods =['POST'])
def insert_data():
    if request.method == "POST":
        data = Data(
            task = request.form.get('task'),
            des = request.form.get('des'),
            dat = request.form.get('dat')
        )
        db.session.add(data)
        db.session.commit()
        flash("Task added successfully")
        return redirect(url_for('index'))


@app.route('/update/', methods = ['POST'])
def update():
    if request.method == "POST":
        my_data = Data.query.get(request.form.get('id'))

        my_data.task = request.form['task']
        my_data.des = request.form['des']
        my_data.dat = request.form['dat']

        db.session.commit()
        flash("Task is updated")
        return redirect(url_for('index'))

@app.route('/delete/<id>/', methods = ['GET', 'POST'])
def delete(id):
    my_data = Data.query.get(id)
    db.session.delete(my_data)
    db.session.commit()
    flash("Task is Completed")
    return redirect(url_for('index'))

if __name__ == "__main__":
    app.run(debug=True)